﻿#include "lab3.h"   // Заголовковий файл з оголошеннями функцій DLL
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <windows.h> // Для роботи з часом (SYSTEMTIME, GetLocalTime)
using namespace std;


// --- Додаткова функція для виводу поточного часу ---
static void ShowLocalTime() {
    SYSTEMTIME stLocal; // Структура для зберігання системного часу
    GetLocalTime(&stLocal); // Отримання локального часу системи

    CHAR buffer[256]; // Буфер для текстового представлення часу
    sprintf_s(buffer, "%02d:%02d:%02d - ",
        stLocal.wHour, stLocal.wMinute, stLocal.wSecond);

    cout << buffer; // Виводимо час перед кожним повідомленням
}


// --- Основна функція програми ---
int main()
{
    // Налаштування кодування, щоб український текст відображався коректно
    SetConsoleCP(1251);          // Введення з консолі у кодуванні Windows-1251
    SetConsoleOutputCP(1251);    // Вивід у тому ж кодуванні
    setlocale(LC_ALL, "Ukrainian");

    // --- Початок виконання головної програми ---
    ShowLocalTime(); cout << "[Implicit MAIN] старт головної програми\n";

    // 📌 Пояснення:
    // Якщо DLL підключено неявно (через .lib або pragma comment(lib, ...)),
    // то функція DllMain у DLL автоматично викликається ще ДО старту main().
    // У консолі ти побачиш повідомлення з DllMain перед цим рядком.

    ShowLocalTime(); cout << "[Implicit MAIN] DllMain(ATTACH) вже мав виконатись\n\n";


    // --- Введення тексту від користувача ---
    char myString[128];
    printf("Enter string: ");
    gets_s(myString, sizeof(myString)); // Безпечне зчитування введеного рядка


    // --- Виклик функції з DLL ---
    ShowLocalTime(); cout << "[Implicit MAIN] Виклик функції processUniqueLetters()...\n";

    // processUniqueLetters() — експортується з DLL.
    // Приймає рядок і повертає новий, у якому видалено повторювані символи в кожному слові.
    // Наприклад: "hello world" → "helo world".
    char* result = processUniqueLetters(myString);

    ShowLocalTime(); cout << "[Implicit MAIN] Функція processUniqueLetters() завершила роботу\n\n";


    // --- Вивід результату ---
    if (result) {
        printf("Result: %s\n\n", result);
    }


    // --- Виклик допоміжних (тестових) функцій із DLL ---
    ShowLocalTime(); cout << "[Implicit MAIN] Виклик функцій-заглушок...\n";

    dummyFunction1(); // Виведе повідомлення у консоль із DLL
    int dummyResult = dummyFunction2(10); // Повертає testValue * 2

    ShowLocalTime(); cout << "[Implicit MAIN] dummyFunction2(10) повернула: " << dummyResult << "\n\n";


    // --- Завершення роботи ---
    ShowLocalTime(); cout << "[Implicit MAIN] Завершення головної програми\n";

    // Після виходу з main() система автоматично викликає DllMain(DLL_PROCESS_DETACH),
    // що означає, що DLL буде вивантажено, і ти побачиш це повідомлення у консолі.

    return 0;
}
