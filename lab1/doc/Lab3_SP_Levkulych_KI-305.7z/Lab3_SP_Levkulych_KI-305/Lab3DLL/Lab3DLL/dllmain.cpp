﻿#include "pch.h"
#include "lab3.h"   // Підключення заголовкового файлу з описами функцій DLL
#include <string.h> // Для strlen, memset — робота з рядками
#include <ctype.h>  // Для роботи з символами (наприклад, isalpha, isdigit)
#include <stdlib.h> // Для malloc, free — динамічне виділення пам’яті

// ДОДАНО
#include <windows.h> // Для структури SYSTEMTIME та функцій GetLocalTime
#include <stdio.h>   // Для printf — виведення інформації у консоль
#include <iostream>  // Для SetConsoleOutputCP — налаштування кодування консолі


// --- Точка входу в DLL ---
BOOL APIENTRY DllMain(HMODULE hModule,
    DWORD  ul_reason_for_call,
    LPVOID lpReserved
)
{
    // Встановлення українського/кириличного кодування в консолі Windows
    SetConsoleOutputCP(1251);

    SYSTEMTIME stLocal;      // Структура для зберігання поточного часу
    GetLocalTime(&stLocal);  // Отримуємо локальний системний час

    // Виведення часу виклику DllMain у консоль
    printf("%02d:%02d:%02d - запуск DllMain (ATTACH/DETACH)\n",
        stLocal.wHour, stLocal.wMinute, stLocal.wSecond);

    // Обробка подій підключення/відключення DLL
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:  // DLL підключено до процесу
        printf("ul_reason_for_call == %02d (DLL_PROCESS_ATTACH)\n\n", DLL_PROCESS_ATTACH);
        break;

    case DLL_THREAD_ATTACH:   // Новий потік приєднався до процесу
        printf("ul_reason_for_call == %02d (DLL_THREAD_ATTACH)\n\n", DLL_THREAD_ATTACH);
        break;

    case DLL_THREAD_DETACH:   // Потік завершує роботу
        printf("ul_reason_for_call == %02d (DLL_THREAD_DETACH)\n\n", DLL_THREAD_DETACH);
        break;

    case DLL_PROCESS_DETACH:  // DLL відключено від процесу
        printf("ul_reason_for_call == %02d (DLL_PROCESS_DETACH)\n\n", DLL_PROCESS_DETACH);
        break;
    }
    return TRUE; // DLL ініціалізована успішно
}



// --- Експортована функція processUniqueLetters ---
// Призначення: видаляє повторювані символи всередині кожного слова рядка
// Наприклад: "hello world" → "helo world"
extern "C" __declspec(dllexport) char* processUniqueLetters(const char* input) {
    if (!input) return nullptr;  // Перевірка на порожній вхідний рядок

    size_t len = strlen(input);  // Довжина вхідного рядка
    char* result = (char*)malloc(len + 1); // Виділення пам’яті під результат
    if (!result) return nullptr;  // Якщо пам’ять не виділено — вихід

    size_t resultIndex = 0;       // Індекс для запису у result
    bool inWord = false;          // Чи зараз ми всередині слова
    bool usedLetters[256] = { false }; // Таблиця використаних символів (ASCII)

    // Проходимо по всьому рядку
    for (size_t i = 0; i <= len; i++) {
        if (input[i] == ' ' || input[i] == '\0') {
            // Якщо зустріли пробіл або кінець рядка
            if (inWord) {
                memset(usedLetters, 0, sizeof(usedLetters)); // Скидаємо використані символи
                result[resultIndex++] = ' '; // Додаємо пробіл після слова
                inWord = false;              // Виходимо зі стану слова
            }
            else if (i < len) {
                // Якщо кілька пробілів підряд — зберігаємо їх
                result[resultIndex++] = ' ';
            }
        }
        else {
            // Якщо натрапили на символ слова
            if (!inWord) {
                inWord = true;
                memset(usedLetters, 0, sizeof(usedLetters)); // Очищаємо перед новим словом
            }

            unsigned char c = (unsigned char)input[i];
            if (!usedLetters[c]) {        // Якщо символ ще не зустрічався у цьому слові
                usedLetters[c] = true;    // Позначаємо, що його вже використали
                result[resultIndex++] = input[i]; // Додаємо до результату
            }
        }
    }

    // Якщо останній символ — пробіл, видаляємо його
    if (resultIndex > 0 && result[resultIndex - 1] == ' ') {
        resultIndex--;
    }

    result[resultIndex] = '\0'; // Завершуємо рядок нульовим символом
    return result;              // Повертаємо новий оброблений рядок
}



// --- Функція-заглушка 1 ---
// Викликається для демонстрації експорту функцій
extern "C" __declspec(dllexport) void dummyFunction1(void) {
    printf("--- [DLL] Викликано dummyFunction1() ---\n");
}



// --- Функція-заглушка 2 ---
// Проста функція, яка приймає число, виводить його і повертає подвоєне
extern "C" __declspec(dllexport) int dummyFunction2(int testValue) {
    printf("--- [DLL] Викликано dummyFunction2() з %d, повертаю %d ---\n",
        testValue, testValue * 2);
    return testValue * 2;
}
